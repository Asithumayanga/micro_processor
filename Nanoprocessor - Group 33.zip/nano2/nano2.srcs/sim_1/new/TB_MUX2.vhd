library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity TB_MUX2 is
end TB_MUX2;

architecture Behavioral of TB_MUX2 is

    component MUX2 is
        Port ( A   : in  STD_LOGIC_VECTOR(2 downto 0);
               B   : in  STD_LOGIC_VECTOR(2 downto 0);
               Sel : in  STD_LOGIC;
               O   : out STD_LOGIC_VECTOR(2 downto 0));
    end component;

    signal A, B : STD_LOGIC_VECTOR(2 downto 0) := "000";
    signal Sel  : STD_LOGIC := '0';
    signal O    : STD_LOGIC_VECTOR(2 downto 0);

begin

    UUT : MUX2 port map (A => A, B => B, Sel => Sel, O => O);

    process
    begin
        -- Test 1: Sel=0 passes A
        A <= "001"; B <= "110"; Sel <= '0'; wait for 100 ns;

        -- Test 2: Sel=1 passes B
        Sel <= '1'; wait for 100 ns;

        -- Test 3: PC sequential address (Sel=0)
        A <= "011"; B <= "101"; Sel <= '0'; wait for 100 ns;

        -- Test 4: Jump address (Sel=1)
        Sel <= '1'; wait for 100 ns;

        -- Test 5: Both inputs same
        A <= "100"; B <= "100"; Sel <= '0'; wait for 100 ns;
        Sel <= '1'; wait for 100 ns;

        -- Test 6: All zeros vs all ones
        A <= "000"; B <= "111"; Sel <= '0'; wait for 100 ns;
        Sel <= '1'; wait for 100 ns;

        wait;
    end process;

end Behavioral;