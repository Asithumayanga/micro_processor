library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity TB_3to8_Dec is
end TB_3to8_Dec;

architecture Behavioral of TB_3to8_Dec is

    component Decoder_8 is
        Port ( Sel : in  STD_LOGIC_VECTOR(2 downto 0);
               O   : out STD_LOGIC_VECTOR(7 downto 0));
    end component;

    signal Sel : STD_LOGIC_VECTOR(2 downto 0) := "000";
    signal O   : STD_LOGIC_VECTOR(7 downto 0);

begin

    UUT : Decoder_8 port map (Sel => Sel, O => O);

    process
    begin
        Sel <= "000"; wait for 60 ns;
        Sel <= "001"; wait for 60 ns;
        Sel <= "010"; wait for 60 ns;
        Sel <= "011"; wait for 60 ns;
        Sel <= "100"; wait for 60 ns;
        Sel <= "101"; wait for 60 ns;
        Sel <= "110"; wait for 60 ns;
        Sel <= "111"; wait for 60 ns;
        Sel <= "011"; wait for 60 ns;
        wait;
    end process;

end Behavioral;