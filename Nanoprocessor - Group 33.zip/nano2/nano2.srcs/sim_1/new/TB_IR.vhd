library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity TB_IR is
end TB_IR;

architecture Behavioral of TB_IR is

    component Instruction_Decoder is
        Port ( Instruction : in  STD_LOGIC_VECTOR(11 downto 0);
               JumpCheck   : in  STD_LOGIC_VECTOR(3 downto 0);
               RegEn       : out STD_LOGIC_VECTOR(2 downto 0);
               Sel_A       : out STD_LOGIC_VECTOR(2 downto 0);
               Sel_B       : out STD_LOGIC_VECTOR(2 downto 0);
               LoadSel     : out STD_LOGIC;
               ImmVal      : out STD_LOGIC_VECTOR(3 downto 0);
               Sub         : out STD_LOGIC;
               JumpFlag    : out STD_LOGIC;
               JumpAddress : out STD_LOGIC_VECTOR(2 downto 0));
    end component;

    signal Instruction : STD_LOGIC_VECTOR(11 downto 0) := (others => '0');
    signal JumpCheck   : STD_LOGIC_VECTOR(3 downto 0)  := (others => '0');
    signal RegEn       : STD_LOGIC_VECTOR(2 downto 0);
    signal Sel_A       : STD_LOGIC_VECTOR(2 downto 0);
    signal Sel_B       : STD_LOGIC_VECTOR(2 downto 0);
    signal LoadSel     : STD_LOGIC;
    signal ImmVal      : STD_LOGIC_VECTOR(3 downto 0);
    signal Sub         : STD_LOGIC;
    signal JumpFlag    : STD_LOGIC;
    signal JumpAddress : STD_LOGIC_VECTOR(2 downto 0);

begin

    UUT : Instruction_Decoder
        port map (
            Instruction => Instruction,
            JumpCheck   => JumpCheck,
            RegEn       => RegEn,
            Sel_A       => Sel_A,
            Sel_B       => Sel_B,
            LoadSel     => LoadSel,
            ImmVal      => ImmVal,
            Sub         => Sub,
            JumpFlag    => JumpFlag,
            JumpAddress => JumpAddress
        );

    process
    begin
        -- Test 1a: ADD R7, R1
        Instruction <= "001110010000"; JumpCheck <= "0000"; wait for 60 ns;

        -- Test 1b: ADD R2, R1
        Instruction <= "000100010000"; JumpCheck <= "0000"; wait for 60 ns;

        -- Test 2a: NEG R1
        Instruction <= "010010000000"; JumpCheck <= "0000"; wait for 60 ns;

        -- Test 2b: NEG R7
        Instruction <= "011110000000"; JumpCheck <= "0000"; wait for 60 ns;

        -- Test 3a: MOVI R7, 3
        Instruction <= "101110000011"; JumpCheck <= "0000"; wait for 60 ns;

        -- Test 3b: MOVI R1, 1
        Instruction <= "100010000001"; JumpCheck <= "0000"; wait for 60 ns;

        -- Test 3c: MOVI R2, 3
        Instruction <= "100100000011"; JumpCheck <= "0000"; wait for 60 ns;

        -- Test 4a: JZR R0, 4 - JumpCheck=0 -> should jump
        Instruction <= "110000000100"; JumpCheck <= "0000"; wait for 60 ns;

        -- Test 4b: JZR R2, 6 - JumpCheck=0 -> should jump
        Instruction <= "110100000110"; JumpCheck <= "0000"; wait for 60 ns;

        -- Test 4c: JZR R2, 6 - JumpCheck non-zero -> no jump
        Instruction <= "110100000110"; JumpCheck <= "0010"; wait for 60 ns;

        -- Test 4d: JZR R7, 2 - JumpCheck non-zero -> no jump
        Instruction <= "111110000010"; JumpCheck <= "1111"; wait for 60 ns;

        wait;
    end process;

end Behavioral;