library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity TB_adder_4bit is
end TB_adder_4bit;

architecture Behavioral of TB_adder_4bit is

    component adder_4bit is
        Port ( A     : in  STD_LOGIC_VECTOR(3 downto 0);
               B     : in  STD_LOGIC_VECTOR(3 downto 0);
               C_in  : in  STD_LOGIC;
               S     : out STD_LOGIC_VECTOR(3 downto 0);
               C_out : out STD_LOGIC);
    end component;

    signal A, B  : STD_LOGIC_VECTOR(3 downto 0) := (others => '0');
    signal C_in  : STD_LOGIC := '0';
    signal S     : STD_LOGIC_VECTOR(3 downto 0);
    signal C_out : STD_LOGIC;

begin

    UUT : Adder_4bit
        port map (A => A, B => B, C_in => C_in, S => S, C_out => C_out);

    process
    begin
        -- Test 1: 0 + 0 = 0
        A <= "0000"; B <= "0000"; C_in <= '0'; wait for 50 ns;

        -- Test 2: 1 + 1 = 2
        A <= "0001"; B <= "0001"; C_in <= '0'; wait for 50 ns;

        -- Test 3: 5 + 3 = 8
        A <= "0101"; B <= "0011"; C_in <= '0'; wait for 50 ns;

        -- Test 4: 7 + 7 = 14
        A <= "0111"; B <= "0111"; C_in <= '0'; wait for 50 ns;

        -- Test 5: 15 + 1 = 16, sum=0 carry=1
        A <= "1111"; B <= "0001"; C_in <= '0'; wait for 50 ns;

        -- Test 6: 15 + 15 = 30, sum=14 carry=1
        A <= "1111"; B <= "1111"; C_in <= '0'; wait for 50 ns;

        -- Test 7: 7 + 7 + cin=1 = 15
        A <= "0111"; B <= "0111"; C_in <= '1'; wait for 50 ns;

        -- Test 8: 15 + 0 + cin=1 = 16, sum=0 carry=1
        A <= "1111"; B <= "0000"; C_in <= '1'; wait for 50 ns;

        -- Test 9: 3 + 12 = 15
        A <= "0011"; B <= "1100"; C_in <= '0'; wait for 50 ns;

        -- Test 10: 8 + 8 = 16, sum=0 carry=1
        A <= "1000"; B <= "1000"; C_in <= '0'; wait for 50 ns;

        wait;
    end process;

end Behavioral;