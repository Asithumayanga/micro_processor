library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity TB_LS is
end TB_LS;

architecture Behavioral of TB_LS is

    component Load_Selector is
        Port ( A   : in  STD_LOGIC_VECTOR(3 downto 0);
               B   : in  STD_LOGIC_VECTOR(3 downto 0);
               Sel : in  STD_LOGIC;
               O   : out STD_LOGIC_VECTOR(3 downto 0));
    end component;

    signal A, B : STD_LOGIC_VECTOR(3 downto 0) := (others => '0');
    signal Sel  : STD_LOGIC := '0';
    signal O    : STD_LOGIC_VECTOR(3 downto 0);

begin

    UUT : Load_Selector port map (A => A, B => B, Sel => Sel, O => O);

    process
    begin
        -- ---- Test 1: Sel=0 ? ALU result (A) ----
        A <= "1010"; B <= "0101"; Sel <= '0'; wait for 100 ns;

        -- ---- Test 2: Sel=1 ? Immediate value (B) ----
        Sel <= '1'; wait for 100 ns;

        -- ---- Test 3: MOVI R7,3 ? immediate=0011 ----
        A <= "1111"; B <= "0011"; Sel <= '1'; wait for 100 ns;

        -- ---- Test 4: ADD result ? ALU path ----
        A <= "0111"; B <= "0000"; Sel <= '0'; wait for 100 ns;

        -- ---- Test 5: Zero immediate ----
        A <= "1111"; B <= "0000"; Sel <= '1'; wait for 100 ns;

        -- ---- Test 6: Max immediate value 15 ----
        B <= "1111"; Sel <= '1'; wait for 100 ns;

        wait;
    end process;

end Behavioral;