library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity TB_PC_Inc is
end TB_PC_Inc;

architecture Behavioral of TB_PC_Inc is

    component PC_Inc is
        Port ( Q : in  STD_LOGIC_VECTOR(2 downto 0);
               D : out STD_LOGIC_VECTOR(2 downto 0));
    end component;

    signal Q : STD_LOGIC_VECTOR(2 downto 0) := "000";
    signal D : STD_LOGIC_VECTOR(2 downto 0);

begin

    UUT : PC_Inc port map (Q => Q, D => D);

    process
    begin
        -- Test all 8 PC values
        Q <= "000"; wait for 100 ns;
        Q <= "001"; wait for 100 ns;
        Q <= "010"; wait for 100 ns;
        Q <= "011"; wait for 100 ns;
        Q <= "100"; wait for 100 ns;
        Q <= "101"; wait for 100 ns;
        Q <= "110"; wait for 100 ns;
        
        -- Wrap-around: 7 + 1 = 0 (3-bit overflow)
        Q <= "111"; wait for 100 ns;

        wait;
    end process;

end Behavioral;