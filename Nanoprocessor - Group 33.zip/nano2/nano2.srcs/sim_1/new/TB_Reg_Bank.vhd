library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity TB_Reg_Bank is
end TB_Reg_Bank;

architecture Behavioral of TB_Reg_Bank is

    component Register_Bank is
        Port ( RegEn : in  STD_LOGIC_VECTOR(2 downto 0);
               Data  : in  STD_LOGIC_VECTOR(3 downto 0);
               Clk   : in  STD_LOGIC;
               Res   : in  STD_LOGIC;
               Reg0  : out STD_LOGIC_VECTOR(3 downto 0);
               Reg1  : out STD_LOGIC_VECTOR(3 downto 0);
               Reg2  : out STD_LOGIC_VECTOR(3 downto 0);
               Reg3  : out STD_LOGIC_VECTOR(3 downto 0);
               Reg4  : out STD_LOGIC_VECTOR(3 downto 0);
               Reg5  : out STD_LOGIC_VECTOR(3 downto 0);
               Reg6  : out STD_LOGIC_VECTOR(3 downto 0);
               Reg7  : out STD_LOGIC_VECTOR(3 downto 0));
    end component;

    signal Clk  : STD_LOGIC := '0';
    signal Res  : STD_LOGIC := '1';
    signal RegEn: STD_LOGIC_VECTOR(2 downto 0) := "000";
    signal Data : STD_LOGIC_VECTOR(3 downto 0) := (others => '0');
    signal Reg0,Reg1,Reg2,Reg3 : STD_LOGIC_VECTOR(3 downto 0);
    signal Reg4,Reg5,Reg6,Reg7 : STD_LOGIC_VECTOR(3 downto 0);

    constant CLK_PERIOD : time := 20 ns;

begin

    UUT : Register_Bank
        port map (RegEn=>RegEn, Data=>Data, Clk=>Clk, Res=>Res,
                  Reg0=>Reg0, Reg1=>Reg1, Reg2=>Reg2, Reg3=>Reg3,
                  Reg4=>Reg4, Reg5=>Reg5, Reg6=>Reg6, Reg7=>Reg7);

    Clk <= not Clk after CLK_PERIOD / 2;

    stim : process
    begin
        -- Reset: all registers should be 0
        Res <= '1'; wait for CLK_PERIOD;

        Res <= '0'; wait for 5 ns;

        -- R0 is permanently zero - attempt to write
        RegEn <= "000"; Data <= "1111"; wait for CLK_PERIOD;

        -- Write R1 = 1
        RegEn <= "001"; Data <= "0001"; wait for CLK_PERIOD;

        -- Write R2 = 2
        RegEn <= "010"; Data <= "0010"; wait for CLK_PERIOD;

        -- Write R3 = 3
        RegEn <= "011"; Data <= "0011"; wait for CLK_PERIOD;

        -- Write R4 = 4
        RegEn <= "100"; Data <= "0100"; wait for CLK_PERIOD;

        -- Write R5 = 5
        RegEn <= "101"; Data <= "0101"; wait for CLK_PERIOD;

        -- Write R6 = 6
        RegEn <= "110"; Data <= "0110"; wait for CLK_PERIOD;

        -- Write R7 = 7
        RegEn <= "111"; Data <= "0111"; wait for CLK_PERIOD;

        -- Overwrite R7 = 15
        RegEn <= "111"; Data <= "1111"; wait for CLK_PERIOD;

        -- Reset again
        Res <= '1'; wait for CLK_PERIOD;

        wait;
    end process;

end Behavioral;