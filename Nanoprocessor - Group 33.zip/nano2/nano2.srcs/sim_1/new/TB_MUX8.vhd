library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity TB_MUX8 is
end TB_MUX8;

architecture Behavioral of TB_MUX8 is

    component MUX8 is
        Port ( Sel : in  STD_LOGIC_VECTOR(2 downto 0);
               I0  : in  STD_LOGIC_VECTOR(3 downto 0);
               I1  : in  STD_LOGIC_VECTOR(3 downto 0);
               I2  : in  STD_LOGIC_VECTOR(3 downto 0);
               I3  : in  STD_LOGIC_VECTOR(3 downto 0);
               I4  : in  STD_LOGIC_VECTOR(3 downto 0);
               I5  : in  STD_LOGIC_VECTOR(3 downto 0);
               I6  : in  STD_LOGIC_VECTOR(3 downto 0);
               I7  : in  STD_LOGIC_VECTOR(3 downto 0);
               O   : out STD_LOGIC_VECTOR(3 downto 0));
    end component;

    signal Sel          : STD_LOGIC_VECTOR(2 downto 0) := "000";
    signal I0,I1,I2,I3 : STD_LOGIC_VECTOR(3 downto 0);
    signal I4,I5,I6,I7 : STD_LOGIC_VECTOR(3 downto 0);
    signal O            : STD_LOGIC_VECTOR(3 downto 0);

begin

    I0 <= "0000";
    I1 <= "0001";
    I2 <= "0010";
    I3 <= "0011";
    I4 <= "0100";
    I5 <= "0101";
    I6 <= "0110";
    I7 <= "0111";

    UUT : MUX8
        port map (
        Sel=>Sel, I0=>I0, I1=>I1,
        I2=>I2, I3=>I3, I4=>I4, 
        I5=>I5, I6=>I6, I7=>I7, O=>O
        );

    process
    begin
        Sel <= "000"; wait for 10 ns;
        Sel <= "001"; wait for 10 ns;
        Sel <= "010"; wait for 10 ns;
        Sel <= "011"; wait for 10 ns;
        Sel <= "100"; wait for 10 ns;
        Sel <= "101"; wait for 10 ns;
        Sel <= "110"; wait for 10 ns;
        Sel <= "111"; wait for 10 ns;
        wait;
    end process;

end Behavioral;