library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity TB_7Seg_Dis is
end TB_7Seg_Dis;

architecture Behavioral of TB_7Seg_Dis is

    component Display_Driver is
        Port ( Address       : in  STD_LOGIC_VECTOR(3 downto 0);
               driver_signal : out STD_LOGIC_VECTOR(6 downto 0));
    end component;

    signal Address       : STD_LOGIC_VECTOR(3 downto 0) := (others => '0');
    signal driver_signal : STD_LOGIC_VECTOR(6 downto 0);

begin

    UUT : Display_Driver port map (Address => Address, driver_signal => driver_signal);

    process
    begin
        Address <= "0000"; wait for 50 ns;   -- 0
        Address <= "0001"; wait for 50 ns;   -- 1
        Address <= "0010"; wait for 50 ns;   -- 2
        Address <= "0011"; wait for 50 ns;   -- 3
        Address <= "0100"; wait for 50 ns;   -- 4
        Address <= "0101"; wait for 50 ns;   -- 5
        Address <= "0110"; wait for 50 ns;   -- 6
        Address <= "0111"; wait for 50 ns;   -- 7
        Address <= "1000"; wait for 50 ns;   -- 8
        Address <= "1001"; wait for 50 ns;   -- 9
        Address <= "1010"; wait for 50 ns;   -- A
        Address <= "1011"; wait for 50 ns;   -- B
        Address <= "1100"; wait for 50 ns;   -- C
        Address <= "1101"; wait for 50 ns;   -- D
        Address <= "1110"; wait for 50 ns;   -- E
        Address <= "1111"; wait for 50 ns;   -- F
        wait;
    end process;

end Behavioral;