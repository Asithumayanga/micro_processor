library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity TB_Reg_4bit is
end TB_Reg_4bit;

architecture Behavioral of TB_Reg_4bit is
    component Register_4bit is
        Port ( Clk : in  STD_LOGIC;
               Res : in  STD_LOGIC;
               En  : in  STD_LOGIC;
               D   : in  STD_LOGIC_VECTOR(3 downto 0);
               Q   : out STD_LOGIC_VECTOR(3 downto 0));
    end component;

    signal Clk : STD_LOGIC := '0';
    signal Res : STD_LOGIC := '0';
    signal En  : STD_LOGIC := '0';
    signal D   : STD_LOGIC_VECTOR(3 downto 0) := (others => '0');
    signal Q   : STD_LOGIC_VECTOR(3 downto 0);

    constant CLK_PERIOD : time := 20 ns;
begin
    UUT : Register_4bit
        port map (Clk => Clk, Res => Res, En => En, D => D, Q => Q);

    Clk <= not Clk after CLK_PERIOD / 2;

    process
    begin
        -- Test 1: Synchronous reset clears output
        Res <= '1'; En <= '0'; D <= "1010";
        wait for CLK_PERIOD;

        -- Test 2: Data NOT captured when En=0
        Res <= '0'; En <= '0'; D <= "1010";
        wait for CLK_PERIOD;

        -- Test 3: Enable=1 -> data captured on rising edge
        En <= '1'; D <= "1010";
        wait for CLK_PERIOD;

        -- Test 4: Different data value
        D <= "0101";
        wait for CLK_PERIOD;

        -- Test 5: En=0 -> data held
        En <= '0'; D <= "1111";
        wait for CLK_PERIOD;

        -- Test 6: Synchronous reset overrides enable
        En <= '1'; Res <= '1'; D <= "1111";
        wait for CLK_PERIOD;

        -- Test 7: Load 0xF
        Res <= '0'; En <= '1'; D <= "1111";
        wait for CLK_PERIOD;

        -- Test 8: Load 0x0
        D <= "0000";
        wait for CLK_PERIOD;

        wait;
    end process;
end Behavioral;