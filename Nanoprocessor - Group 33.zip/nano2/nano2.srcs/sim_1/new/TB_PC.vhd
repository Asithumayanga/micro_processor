library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity TB_PC is
end TB_PC;

architecture Behavioral of TB_PC is

    component Register_PC is
        Port ( Clk : in  STD_LOGIC;
               Res : in  STD_LOGIC;
               D   : in  STD_LOGIC_VECTOR(2 downto 0);
               Q   : out STD_LOGIC_VECTOR(2 downto 0));
    end component;

    signal Clk : STD_LOGIC := '0';
    signal Res : STD_LOGIC := '0';
    signal D   : STD_LOGIC_VECTOR(2 downto 0) := "000";
    signal Q   : STD_LOGIC_VECTOR(2 downto 0);

begin

    UUT : Register_PC
        port map (Clk => Clk, Res => Res, D => D, Q => Q);

    Clk <= not Clk after 25 ns;

    process
    begin
        -- Test 1: Async reset fires immediately without waiting for clock
        D <= "111"; Res <= '1';
        wait for 5 ns;

        -- Test 2: Hold reset, data ignored
        wait for 50 ns;

        -- Test 3: Release reset, load PC=1
        Res <= '0'; D <= "001";
        wait for 50 ns;

        -- Test 4: Sequential increment simulation
        D <= "010"; wait for 50 ns;
        D <= "011"; wait for 50 ns;
        D <= "100"; wait for 50 ns;

        -- Test 5: Jump target load
        D <= "110"; wait for 50 ns;

        -- Test 6: Async reset mid-execution
        D <= "111";
        wait for 3 ns;
        Res <= '1';
        wait for 2 ns;

        -- Test 7: Resume after reset
        Res <= '0'; wait for 50 ns;
        D <= "101"; wait for 50 ns;

        wait;
    end process;

end Behavioral;