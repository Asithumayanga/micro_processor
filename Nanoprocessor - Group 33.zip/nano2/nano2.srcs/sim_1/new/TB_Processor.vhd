library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

-- ============================================================
--  Testbench : TB_NanoProcessor
--  DUT       : Processer (complete processor)
--
--  Loaded program (from Program_ROM):
--    Addr 0: MOVI R7, 3   ? R7 = 3
--    Addr 1: MOVI R1, 1   ? R1 = 1
--    Addr 2: NEG  R1      ? R1 = -1 (0xF = 15)
--    Addr 3: MOVI R2, 3   ? R2 = 3
--    Addr 4: ADD  R2, R1  ? R2 = R2 + R1 = 3 + 15 = 2 (wraps) ? R2 = 2
--    Addr 5: ADD  R7, R2  ? R7 = R7 + R2 = 3 + 2 = 5
--    Addr 6: JZR  R2, 6   ? R2 != 0 ? no jump ? PC = 7
--    Addr 7: JZR  R0, 4   ? R0 = 0  ? jump to 4 (always)
--
--  Expected R7 progression: 3 ? 5 ? 7 ? 9 ? 11 ? ... (+2 each loop)
-- ============================================================
entity TB_Processor is
end TB_Processor;

architecture Behavioral of TB_Processor is

    component Processer is
        Port ( Reset    : in  STD_LOGIC;
               Clk      : in  STD_LOGIC;
               Overflow : out STD_LOGIC;
               Zero     : out STD_LOGIC;
               R7       : out STD_LOGIC_VECTOR(3 downto 0));
    end component;

    signal Clk      : STD_LOGIC := '0';
    signal Reset    : STD_LOGIC := '1';
    signal Overflow : STD_LOGIC;
    signal Zero     : STD_LOGIC;
    signal R7       : STD_LOGIC_VECTOR(3 downto 0);

    constant CLK_PERIOD : time := 20 ns;

begin

    UUT : Processer
        port map (Reset => Reset, Clk => Clk,
                  Overflow => Overflow, Zero => Zero, R7 => R7);

    Clk <= not Clk after CLK_PERIOD / 2;

    process
    begin
        -- ---- Apply Reset ----
        Reset <= '1';
        wait for CLK_PERIOD * 2;
        Reset <= '0';
        wait for CLK_PERIOD / 2;  -- align to just after rising edge

        -- ---- Cycle 0: MOVI R7, 3 ----
        wait for CLK_PERIOD;
        -- ---- Cycle 1: MOVI R1, 1 ----
        wait for CLK_PERIOD;
        -- ---- Cycle 2: NEG R1 ----
        wait for CLK_PERIOD;
        -- ---- Cycle 3: MOVI R2, 3 ----
        wait for CLK_PERIOD;
        -- ---- Cycle 4: ADD R2, R1  (R2 = 3 + NEG(1) = 3-1 = 2) ----
        wait for CLK_PERIOD;
        -- ---- Cycle 5: ADD R7, R2  (R7 = 3 + 2 = 5) ----
        wait for CLK_PERIOD;
        wait for CLK_PERIOD / 2;

        -- ---- Cycle 6: JZR R2, 6 (R2=2 /= 0, no jump, PC?7) ----
        wait for CLK_PERIOD;
        -- ---- Cycle 7: JZR R0, 4 (R0=0, always jump to 4) ----
        wait for CLK_PERIOD;

        -- ---- Second iteration: ADD R2, R1 again ? R2 wraps differently ----
        -- Addr 4: ADD R2, R1 ? R2 = 2 + 15 = 1 (wrap)
        -- Addr 5: ADD R7, R2 ? R7 = 5 + 1 = 6  (but depends on R2)
        -- Let the processor run several more loops
        wait for CLK_PERIOD * 4;

        -- ---- Test Reset mid-execution ----
        Reset <= '1';
        wait for CLK_PERIOD * 2;

        -- ---- Resume and check R7 loads again ----
        Reset <= '0';
        wait for CLK_PERIOD * 6;  -- allow MOVI R7,3 and first ADD to execute

        wait;
    end process;

end Behavioral;