library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity TB_Slow_Clk is
end entity TB_Slow_Clk;

architecture Behavioral of TB_Slow_Clk is

    component Slow_Clk
        generic (
            N : INTEGER := 2       
        );
        port (
            clk_in  : in  std_logic;
            clk_out : out std_logic 
        );
    end component;

    signal clk_in  : std_logic := '0';
    signal clk_out : std_logic;

    constant clk_period : time := 20 ns;

begin

    uut: Slow_Clk
        generic map (
            N => 2              
        )
        port map (
            clk_in  => clk_in,
            clk_out => clk_out   
        );

    clk_process : process
    begin
        while true loop
            clk_in <= '0';
            wait for clk_period / 2;
            clk_in <= '1';
            wait for clk_period / 2;
        end loop;
    end process;

    stim_process : process
    begin
        wait for 100 ns;
        wait for 1000 ns;
        wait for 40 ns;
        wait for 1000 ns;
        wait;
    end process;

end architecture Behavioral;