library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity TB_Program_ROM is
end TB_Program_ROM;

architecture Behavioral of TB_Program_ROM is

    component Program_ROM is
        Port ( ROM_address : in  STD_LOGIC_VECTOR(2 downto 0);
               I           : out STD_LOGIC_VECTOR(11 downto 0));
    end component;

    signal ROM_address : STD_LOGIC_VECTOR(2 downto 0) := "000";
    signal I           : STD_LOGIC_VECTOR(11 downto 0);

begin

    UUT : Program_ROM port map (ROM_address => ROM_address, I => I);

    process
    begin
        ROM_address <= "000"; wait for 80 ns;
        ROM_address <= "001"; wait for 80 ns;
        ROM_address <= "010"; wait for 80 ns;
        ROM_address <= "011"; wait for 80 ns;
        ROM_address <= "100"; wait for 80 ns;
        ROM_address <= "101"; wait for 80 ns;
        ROM_address <= "110"; wait for 80 ns;
        ROM_address <= "111"; wait for 80 ns;
        ROM_address <= "000"; wait for 80 ns;
        wait;
    end process;

end Behavioral;