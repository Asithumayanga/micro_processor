library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity TB_AU is
end TB_AU;

architecture Behavioral of TB_AU is

    signal A, B  : STD_LOGIC_VECTOR(3 downto 0);
    signal Sub   : STD_LOGIC;
    signal S     : STD_LOGIC_VECTOR(3 downto 0);
    signal Overflow : STD_LOGIC;
    signal Zero     : STD_LOGIC;

    component AU is
        Port ( A        : in  STD_LOGIC_VECTOR(3 downto 0);
               B        : in  STD_LOGIC_VECTOR(3 downto 0);
               Sub      : in  STD_LOGIC;
               S        : out STD_LOGIC_VECTOR(3 downto 0);
               Overflow : out STD_LOGIC;
               Zero     : out STD_LOGIC);
    end component;

begin

    UUT: AU
        port map (
            A        => A,
            B        => B,
            Sub      => Sub,
            S        => S,
            Overflow => Overflow,
            Zero     => Zero
        );

    process
    begin
        -- Test 1: 1 + 2 = 3
        A <= "0001"; B <= "0010"; Sub <= '0'; wait for 50 ns;

        -- Test 2: 4 - 3 = 1
        A <= "0100"; B <= "0011"; Sub <= '1'; wait for 50 ns;

        -- Test 3: 3 - 3 = 0 (zero flag)
        A <= "0011"; B <= "0011"; Sub <= '1'; wait for 50 ns;

        -- Test 4: 7 + 1 = 8 (overflow)
        A <= "0111"; B <= "0001"; Sub <= '0'; wait for 50 ns;

        -- Test 5: 15 + 1 = 16, wraps to 0 (overflow + zero)
        A <= "1111"; B <= "0001"; Sub <= '0'; wait for 50 ns;

        -- Test 6: 8 - 7 = 1
        A <= "1000"; B <= "0111"; Sub <= '1'; wait for 50 ns;

        -- Test 7: 0 + 0 = 0 (zero flag)
        A <= "0000"; B <= "0000"; Sub <= '0'; wait for 50 ns;

        -- Test 8: 5 - 5 = 0 (zero flag)
        A <= "0101"; B <= "0101"; Sub <= '1'; wait for 50 ns;

        wait;
    end process;

end Behavioral;