library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity MUX2 is
    Port ( A : in  STD_LOGIC_VECTOR(2 downto 0);
           B : in  STD_LOGIC_VECTOR(2 downto 0);
           Sel : in  STD_LOGIC;
           O : out STD_LOGIC_VECTOR(2 downto 0));
end MUX2;

architecture Behavioral of MUX2 is

begin
    O <= A when Sel = '0' else B;
end behavioral;